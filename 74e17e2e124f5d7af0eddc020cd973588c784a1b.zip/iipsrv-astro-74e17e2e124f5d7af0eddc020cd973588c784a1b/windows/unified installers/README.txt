To make installers of iipimage you must do following steps.

*************************************REQUIRED STEPS*************************************

1. Build dependencies of iipimage and iipimage. Step by step tutorial, how to build them
   is available here: http://help.oldmapsonline.org/jpeg2000/windows/how-to-build-windows-binaries

2. Download download-and-build-pack.zip from following link and unpack it at the same
   level as iipsrv folder, so you will have iipsrv and download-and-build-pack side by side
   in a folder.
   Link: https://github.com/klokantech/iipsrv/releases/download/D%26B-pack-1.0/download-and-build-pack.zip
   
   Note: If you want to build JPEG2000Transcoder for yourself, you must replace the one
   in download-and-build-pack. Also, if you want to use version of kakadu other than 7.3,
   you must edit this version in scripts.  

3. Open scripts in inno setup and build them

*****************************************************************************************